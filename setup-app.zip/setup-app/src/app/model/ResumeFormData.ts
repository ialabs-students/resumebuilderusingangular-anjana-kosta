export interface ResumeFormData{
    // firstName:string;
    // lastName: string;
    // email: string;
    // pass: string;

    fname:string;
    lname: string;
  email: string;
  mobile: string;
  dob:string;
  gender:string;
  occupation:string;
  type:string;
  langauge:string;
  hobbies:string;
  address:string;
  objective:string;
  university1:string;
  yearofpassing1:string;
  percentage1:string;

  university2:string;
  yearofpassing2:string;
  percentage2:string;

  university3:string;
  yearofpassing3:string;
  percentage3:string;

  university4:string;
  yearofpassing4:string;
  percentage4:string;

  organization1:string;
  doj1:string;
  dor1:string;

  organization2:string;
  doj2:string;
  dor2:string;

  organization3:string;
  doj3:string;
  dor3:string;

  tech1:string;
  version1:string;
  lastworkedon1:string;
  rate1:string;

  tech2:string;
  version2:string;
  lastworkedon2:string;
  rate2:string;

  tech3:string;
  version3:string;
  lastworkedon3:string;
  rate3:string;

  project:string;
  describe:string;
  declare:string;
 // pic: string;

}