export class Menu{
    name: string="";
    id: string="";
    isDropdown: boolean = false;
    
}